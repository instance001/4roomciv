CREATE TABLE IF NOT EXISTS messages (
    msg_id TEXT PRIMARY KEY,
    room TEXT NOT NULL,
    thread_id TEXT,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    attachments TEXT DEFAULT '[]',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS threads (
    thread_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    tags TEXT DEFAULT '[]',
    state TEXT DEFAULT 'open',
    signal_noise REAL DEFAULT 0.0,
    consensus_summary TEXT DEFAULT '',
    consensus_confidence REAL DEFAULT 0.0
);
CREATE TABLE IF NOT EXISTS spines (
    spine_id TEXT PRIMARY KEY,
    timestamp_utc TEXT NOT NULL,
    topic TEXT NOT NULL,
    claim TEXT NOT NULL,
    rationale TEXT DEFAULT '',
    evidence_refs TEXT DEFAULT '[]',
    stance_vector TEXT DEFAULT '[]',
    confidence REAL DEFAULT 0.0,
    context_budget_tokens INTEGER DEFAULT 0,
    prior_spines TEXT DEFAULT '[]',
    next_actions TEXT DEFAULT '[]',
    tags TEXT DEFAULT '[]',
    notes_short TEXT DEFAULT '',
    version INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS spine_topics (
    spine_id TEXT NOT NULL,
    topic_slug TEXT NOT NULL,
    PRIMARY KEY (spine_id, topic_slug),
    FOREIGN KEY (spine_id) REFERENCES spines(spine_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_spine_topics_slug ON spine_topics(topic_slug);
CREATE INDEX IF NOT EXISTS idx_spines_timestamp ON spines(timestamp_utc);
CREATE VIRTUAL TABLE IF NOT EXISTS spines_fts USING fts5(
    claim, rationale, content='spines', content_rowid='rowid'
);
CREATE TRIGGER IF NOT EXISTS spines_ai AFTER INSERT ON spines BEGIN
  INSERT INTO spines_fts(rowid, claim, rationale) VALUES (new.rowid, new.claim, new.rationale);
END;
CREATE TRIGGER IF NOT EXISTS spines_ad AFTER DELETE ON spines BEGIN
  INSERT INTO spines_fts(spines_fts, rowid, claim, rationale) VALUES('delete', old.rowid, old.claim, old.rationale);
END;
CREATE TRIGGER IF NOT EXISTS spines_au AFTER UPDATE ON spines BEGIN
  INSERT INTO spines_fts(spines_fts, rowid, claim, rationale) VALUES('delete', old.rowid, old.claim, old.rationale);
  INSERT INTO spines_fts(rowid, claim, rationale) VALUES (new.rowid, new.claim, new.rationale);
END;
