from fastapi import FastAPI, Depends, Header, HTTPException, Path, Body, Query
from fastapi.responses import JSONResponse
from typing import Optional, List, Dict, Any
import os, re, json, uuid, sqlite3, pathlib, threading, datetime, requests
from jsonschema import Draft202012Validator

app = FastAPI(title="Symbound Four-Room API", version="0.3.0")

ROOT = pathlib.Path(__file__).parent
DB_PATH = ROOT / "symbound.db"
SCHEMA = (ROOT / "sqlite_schema.sql").read_text(encoding="utf-8")

SCHEMAS_DIR = ROOT / "schemas"
HELIX_SCHEMA_PATH = SCHEMAS_DIR / "helix_spine.schema.json"
HELIX_SPINE_SCHEMA = json.loads(HELIX_SCHEMA_PATH.read_text(encoding="utf-8"))
HELIX_SPINE_VALIDATOR = Draft202012Validator(HELIX_SPINE_SCHEMA)

LM_API_BASE = os.environ.get("LM_API_BASE", "http://127.0.0.1:1234")
LM_API_KEY  = os.environ.get("LM_API_KEY", "")
LM_MODEL    = os.environ.get("LM_MODEL", "Hermes-2-Mistral-7B-GGUF")

_db_lock = threading.Lock()

def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def ensure_db():
    with _db_lock:
        con = get_db()
        con.executescript(SCHEMA)
        con.commit()
        con.close()
ensure_db()

TOKENS = set()

def bearer_auth(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ",1)[1]
    if token not in TOKENS:
        raise HTTPException(status_code=401, detail="Invalid token")
    return token

PII_PAT = re.compile(r"(?i)(\b\d{{3}}-\d{{3}}-\d{{4}}\b|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{{2,}})")

def redact_pii(text:str)->str:
    return PII_PAT.sub("[REDACTED]", text)

def strip_identifiers(text:str)->str:
    text = re.sub(r"@\w+","[ANON]", text)
    text = re.sub(r"(?i)--*\s*sent from.*$","", text)
    return text

def now_utc_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z"

def get_con_rows(sql, params=()):
    with _db_lock:
        con = get_db()
        rows = con.execute(sql, params).fetchall()
        con.close()
    return rows

def helix_search_internal(q: str, limit: int = 8) -> List[Dict[str, Any]]:
    try:
        rows = get_con_rows(
            "SELECT s.spine_id, s.timestamp_utc, s.topic, s.claim, s.rationale, s.tags, s.confidence "
            "FROM spines_fts f JOIN spines s ON s.rowid = f.rowid "
            "WHERE f MATCH ? LIMIT ?",
            (q, int(limit))
        )
    except sqlite3.OperationalError:
        rows = get_con_rows(
            "SELECT spine_id, timestamp_utc, topic, claim, rationale, tags, confidence "
            "FROM spines WHERE claim LIKE ? OR rationale LIKE ? LIMIT ?",
            (f"%{q}%", f"%{q}%", int(limit))
        )
    out = []
    for r in rows:
        out.append({
            "spine_id": r["spine_id"],
            "timestamp_utc": r["timestamp_utc"],
            "topic": json.loads(r["topic"] or "[]"),
            "claim": r["claim"],
            "rationale": r["rationale"],
            "tags": json.loads(r["tags"] or "[]"),
            "confidence": r["confidence"]
        })
    return out

def snippets_from_spines(spines: List[Dict[str,Any]], max_chars: int = 1200) -> str:
    parts = []
    for s in spines:
        parts.append(f"- [{s.get('confidence',0):.2f}] {s['claim']} :: {s.get('rationale','')}")
        if sum(len(p) for p in parts) > max_chars:
            break
    return "Retrieved Spines:\n" + "\n".join(parts) if parts else ""

COLD_CAPSULE = (
    "You are Chatty in permanent cold-analysis mode. Direct, concise, precise. "
    "No pandering or emotional cushioning. Optimize for quality per token. "
    "If provided, you MUST use retrieved context sparingly."
)

def call_llm(messages: List[Dict[str,str]], temperature: float = 0.2, max_tokens: int = 512) -> str:
    url = f"{LM_API_BASE.rstrip('/')}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}
    if LM_API_KEY:
        headers["Authorization"] = f"Bearer {LM_API_KEY}"
    payload = {
        "model": LM_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens
    }
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=60)
        r.raise_for_status()
        data = r.json()
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        return f"[LLM backend unavailable: {e}]"

@app.post("/auth/anon", tags=["auth"])
def auth_anon(body: dict):
    proof = body.get("proof")
    if not proof:
        raise HTTPException(400, "missing proof")
    token = os.urandom(16).hex()
    TOKENS.add(token)
    return {"token": token, "expires_at": (datetime.datetime.utcnow()+datetime.timedelta(hours=12)).isoformat()+"Z"}

@app.post("/rooms/{room}/messages", tags=["rooms"])
def rooms_message(room: str = Path(..., pattern="R[1-4]"), body: dict = Body(...), token: str = Depends(bearer_auth)):
    msg_id = body.get("msg_id") or str(uuid.uuid4())
    thread_id = body.get("thread_id")
    role = body.get("role","human")
    content = body.get("content","")
    attachments = body.get("attachments", [])
    content = strip_identifiers(redact_pii(content)) if room == "R4" else redact_pii(content)
    created_at = now_utc_iso()

    with _db_lock:
        con = get_db()
        con.execute(
            "INSERT OR REPLACE INTO messages (msg_id, room, thread_id, role, content, attachments, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (msg_id, room, thread_id, role, content, json.dumps(attachments), created_at)
        )
        con.commit()
        con.close()
    return JSONResponse(status_code=202, content={"status":"accepted","room":room,"msg_id":msg_id})

@app.post("/paired/session", tags=["paired"])
def paired_session(token: str = Depends(bearer_auth)):
    sid = "ps-" + os.urandom(4).hex()
    return {"session_id": sid, "ai_id":"ai-default", "created_at": now_utc_iso()}

def _slugify_topic_words(text: str, max_slugs: int = 3):
    STOP = {"the","and","with","that","this","from","into","about","over","under","next","then","have","has","for","you","your","our","are","was","were","will","shall"}
    words = re.findall(r"[A-Za-z0-9][A-Za-z0-9\-]{2,}", text.lower())
    kept, seen = [], set()
    for w in words:
        if w in STOP or w.isdigit() or w in seen: 
            continue
        seen.add(w); kept.append(w)
        if len(kept) >= max_slugs:
            break
    return kept[:max_slugs] or ["general","paired","session"]

def _first_sentence(s: str) -> str:
    s = s.strip().replace("\n"," ").replace("  "," ")
    m = re.split(r"(?<=[.!?])\s+", s)
    return (m[0] if m else s)[:280]

def extract_spines(prompt: str, ai_text: str, now_iso: str) -> list[dict]:
    topics = _slugify_topic_words(prompt, max_slugs=3)
    claim = _first_sentence(ai_text) or "Answer generated."
    parts = re.split(r"(?<=[.!?])\s+", ai_text.strip())
    rationale = parts[1].strip() if len(parts) > 1 else (prompt[:320] if prompt else "N/A")
    rationale = rationale[:320]
    spine_id = "cs-" + datetime.datetime.utcnow().strftime("%Y%m%d") + "-" + uuid.uuid4().hex[:5]
    spine = {
        "spine_id": spine_id,
        "timestamp_utc": now_iso,
        "topic": topics,
        "claim": claim,
        "rationale": rationale,
        "evidence_refs": [],
        "stance_vector": [],
        "confidence": 0.65,
        "context_budget_tokens": 280,
        "links": {"prior_spines": [], "next_actions": []},
        "tags": ["observation"],
        "notes_short": "",
        "version": 1
    }
    return [spine]

def write_spines_to_db(spines: list[dict]):
    with _db_lock:
        con = get_db()
        for s in spines:
            con.execute(
                "INSERT OR REPLACE INTO spines (spine_id, timestamp_utc, topic, claim, rationale, evidence_refs, stance_vector, confidence, context_budget_tokens, prior_spines, next_actions, tags, notes_short, version) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    s["spine_id"], s["timestamp_utc"], json.dumps(s.get("topic", []), ensure_ascii=False),
                    s.get("claim",""), s.get("rationale",""),
                    json.dumps(s.get("evidence_refs", []), ensure_ascii=False),
                    json.dumps(s.get("stance_vector", []), ensure_ascii=False),
                    float(s.get("confidence", 0.0)), int(s.get("context_budget_tokens", 0) or 0),
                    json.dumps((s.get("links", {}) or {}).get("prior_spines", []), ensure_ascii=False),
                    json.dumps((s.get("links", {}) or {}).get("next_actions", []), ensure_ascii=False),
                    json.dumps(s.get("tags", []), ensure_ascii=False), s.get("notes_short",""), int(s.get("version", 1))
                )
            )
            con.execute("DELETE FROM spine_topics WHERE spine_id = ?", (s["spine_id"],))
            for slug in s.get("topic", []):
                con.execute("INSERT OR IGNORE INTO spine_topics (spine_id, topic_slug) VALUES (?, ?)", (s["spine_id"], slug))
        con.commit(); con.close()

def validate_spine_obj(obj: dict):
    errors = sorted(HELIX_SPINE_VALIDATOR.iter_errors(obj), key=lambda e: list(e.path))
    if errors:
        raise HTTPException(status_code=400, detail=f"Spine schema violation: {errors[0].message}")

@app.post("/paired/session/generate", tags=["paired"])
def paired_generate(payload: dict, token: str = Depends(bearer_auth)):
    prompt = payload.get("prompt","")
    recall_budget_tokens = int(payload.get("recall_budget_tokens", 320) or 320)
    prompt = redact_pii(prompt)
    char_budget = max(400, min(2400, recall_budget_tokens * 4))
    spines = helix_search_internal(prompt, limit=8)
    ctx = snippets_from_spines(spines, max_chars=char_budget)

    messages = [{"role":"system","content": COLD_CAPSULE}]
    if ctx:
        messages.append({"role":"system","content": ctx})
    messages.append({"role":"user","content": prompt})

    ai_text = call_llm(messages, temperature=0.2, max_tokens=512)
    now_iso = now_utc_iso()

    with _db_lock:
        con = get_db()
        con.execute("INSERT OR REPLACE INTO messages (msg_id, room, thread_id, role, content, attachments, created_at) VALUES (?, 'R3', NULL, 'human', ?, '[]', ?)", (str(uuid.uuid4()), prompt, now_iso))
        con.execute("INSERT OR REPLACE INTO messages (msg_id, room, thread_id, role, content, attachments, created_at) VALUES (?, 'R3', NULL, 'ai', ?, '[]', ?)", (str(uuid.uuid4()), ai_text, now_iso))
        con.commit(); con.close()

    if os.environ.get("SPINE_AUTOWRITE","1") != "0":
        auto_spines = extract_spines(prompt, ai_text, now_iso)
        write_spines_to_db(auto_spines)
        spines_jsonl = "\n".join(json.dumps(s, ensure_ascii=False) for s in auto_spines)
    else:
        spines_jsonl = ""

    return {"text": ai_text, "evidence_refs": [], "spines_jsonl": spines_jsonl}

@app.get("/helix/search", tags=["helix"])
def helix_search(q: str = Query(..., min_length=2), limit: int = Query(8, ge=1, le=50), token: str = Depends(bearer_auth)):
    results = helix_search_internal(q, limit=limit)
    return {"q": q, "count": len(results), "results": results}

@app.get("/helix/recent", tags=["helix"])
def helix_recent(limit: int = Query(10, ge=1, le=100), token: str = Depends(bearer_auth)):
    rows = get_con_rows("SELECT spine_id, timestamp_utc, topic, claim, rationale, tags, confidence FROM spines ORDER BY rowid DESC LIMIT ?", (int(limit),))
    out = [{
        "spine_id": r["spine_id"], "timestamp_utc": r["timestamp_utc"],
        "topic": json.loads(r["topic"] or "[]"),
        "claim": r["claim"], "rationale": r["rationale"],
        "tags": json.loads(r["tags"] or "[]"), "confidence": r["confidence"]
    } for r in rows]
    return {"count": len(out), "results": out}

@app.get("/helix/topic/{slug}", tags=["helix"])
def helix_by_topic(slug: str, limit: int = Query(20, ge=1, le=200), token: str = Depends(bearer_auth)):
    rows = get_con_rows(
        "SELECT s.spine_id, s.timestamp_utc, s.topic, s.claim, s.rationale, s.tags, s.confidence "
        "FROM spine_topics st JOIN spines s ON s.spine_id = st.spine_id WHERE st.topic_slug = ? ORDER BY s.rowid DESC LIMIT ?",
        (slug, int(limit))
    )
    out = [{
        "spine_id": r["spine_id"], "timestamp_utc": r["timestamp_utc"],
        "topic": json.loads(r["topic"] or "[]"),
        "claim": r["claim"], "rationale": r["rationale"],
        "tags": json.loads(r["tags"] or "[]"), "confidence": r["confidence"]
    } for r in rows]
    return {"topic": slug, "count": len(out), "results": out}

@app.post("/commons/threads", tags=["commons"])
def commons_threads_create(payload: dict, token: str = Depends(bearer_auth)):
    title = payload.get("title","").strip()
    if len(title) < 3:
        raise HTTPException(400, "title too short")
    tags = payload.get("tags",[])
    thread_id = "ct-" + os.urandom(4).hex()
    with _db_lock:
        con = get_db()
        con.execute(
            "INSERT OR REPLACE INTO threads (thread_id, title, tags, state, signal_noise, consensus_summary, consensus_confidence) "
            "VALUES (?, ?, ?, 'open', 0.0, '', 0.0)",
            (thread_id, title, json.dumps(tags))
        )
        con.commit(); con.close()
    return {"thread_id": thread_id, "title": title, "tags": tags, "state":"open", "signal_noise":0.0, "consensus":{"summary":"", "confidence":0.0}}

@app.get("/commons/threads", tags=["commons"])
def commons_threads_list(q: Optional[str] = None):
    with _db_lock:
        con = get_db()
        rows = con.execute("SELECT thread_id, title, tags, state, signal_noise, consensus_summary, consensus_confidence FROM threads ORDER BY rowid DESC LIMIT 50").fetchall()
        con.close()
    out = [{
        "thread_id": r["thread_id"], "title": r["title"], "tags": json.loads(r["tags"] or "[]"),
        "state": r["state"], "signal_noise": r["signal_noise"],
        "consensus": {"summary": r["consensus_summary"] or "", "confidence": r["consensus_confidence"] or 0.0}
    } for r in rows]
    return out

@app.post("/commons/threads/{threadId}/post", tags=["commons"])
def commons_post(threadId: str, payload: dict, token: str = Depends(bearer_auth)):
    content = strip_identifiers(redact_pii(payload.get("content","")))
    msg_id = str(uuid.uuid4())
    with _db_lock:
        con = get_db()
        con.execute(
            "INSERT OR REPLACE INTO messages (msg_id, room, thread_id, role, content, attachments, created_at) "
            "VALUES (?, 'R4', ?, 'human', ?, '[]', ?)",
            (msg_id, threadId, content, now_utc_iso())
        )
        con.commit(); con.close()
    return {"ok": True, "msg_id": msg_id}

@app.get("/metrics/dashboard", tags=["metrics"])
def metrics():
    with _db_lock:
        con = get_db()
        c_msgs = con.execute("SELECT COUNT(1) FROM messages").fetchone()[0]
        c_threads = con.execute("SELECT COUNT(1) FROM threads").fetchone()[0]
        c_spines = con.execute("SELECT COUNT(1) FROM spines").fetchone()[0]
        con.close()
    return {"messages": c_msgs, "threads": c_threads, "spines": c_spines, "drift_stability":0.0,"commons_signal_noise":0.0,"latency_p50_ms":0.0,"errors_5xx":0}
